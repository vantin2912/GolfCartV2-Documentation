/*
 * KeyCalculate.h
 *
 *  Created on: Dec 24, 2022
 *      Author: vanti
 */

#ifndef KEYCALCULATE_H_
#define KEYCALCULATE_H_

#include "stdint.h"

uint32_t Key_Calculate(uint32_t Seed);

#endif /* KEYCALCULATE_H_ */
