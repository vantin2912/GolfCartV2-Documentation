/*
 * TesterDiagnostic.h
 *
 *  Created on: Dec 2, 2022
 *      Author: vanti
 */

#ifndef TESTERDIAGNOSTIC_H_
#define TESTERDIAGNOSTIC_H_

#include "TesterDefine.h"
#include "CanTP.h"
#include "main.h"

HAL_StatusTypeDef Tester_Init();
HAL_StatusTypeDef Tester_Loop();

#endif /* TESTERDIAGNOSTIC_H_ */
