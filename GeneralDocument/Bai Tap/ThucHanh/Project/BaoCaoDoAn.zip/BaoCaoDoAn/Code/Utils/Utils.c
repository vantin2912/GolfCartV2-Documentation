/*
 * Utils.c
 *
 *  Created on: Dec 24, 2022
 *      Author: vanti
 */

#include <stdint.h>


